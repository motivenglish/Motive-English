let currentIndex = 0;

function changeSlide() {
    const slides = document.querySelectorAll('.carousel-item');
    slides[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % slides.length;
    slides[currentIndex].classList.add('active');
}

setInterval(changeSlide, 5000);

// Enlarge Image
function enlargeImage(postElement) {
    const imageSrc = postElement.querySelector('img').src;
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    modal.style.display = 'block';
    modalImage.src = imageSrc;
}

// Close Modal
function closeModal() {
    document.getElementById('imageModal').style.display = 'none';
}